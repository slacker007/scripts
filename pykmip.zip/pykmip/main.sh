#!/bin/bash

read -p "Before you go on with the installation, have you mades sure to edit the server.conf file appropriately? (Y/N)" -n 1 -r
echo  
if [[ $REPLY =~ ^[Yy]$ ]]
then

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

DEFAULT_USER="$(whoami)"

MY_HOSTNAME="$(ip a s dev eth0 | grep -oP 'inet\s+\K[^/]+')"

cd

sudo yum install python2 -y

sudo yum upgrade python2 -y

sudo yum install git -y

curl https://bootstrap.pypa.io/get-pip.py --output get-pip.py

sudo python2 get-pip.py

pip install PyKMIP

mkdir /home/$DEFAULT_USER/pykmip/ssl/

mkdir /home/$DEFAULT_USER/pykmip/ssl/private

mkdir /home/$DEFAULT_USER/pykmip/ssl/certs

sudo mkdir /etc/pykmip

sudo mkdir /var/log/pykmip

sudo mkdir /etc/ssl/private/

sudo mkdir /etc/ssl/certs/

sudo chown $DEFAULT_USER: -R /etc/pykmip

sudo chown $DEFAULT_USER: -R /var/log/pykmip

openssl req -x509 -nodes -days 3650 -newkey rsa:2048 -subj "/C=NA/ST=NA/L=NA/O=NA/CN=NA" -keyout /home/$DEFAULT_USER/pykmip/ssl/private/selfsigned.key -out /home/$DEFAULT_USER/pykmip/ssl/certs/selfsigned.crt

git -C /home/$DEFAULT_USER/ clone https://github.com/OpenKMIP/PyKMIP


yes | cp -rf $SCRIPT_DIR/server.conf /etc/pykmip/server.conf

#sudo "@reboot ( sleep 30s; python2 /home/$DEFAULT_USER/PyKMIP/bin/run_server.py & )" >> /var/spool/cron/root

python2 /home/$DEFAULT_USER/PyKMIP/bin/run_server.py &

fi